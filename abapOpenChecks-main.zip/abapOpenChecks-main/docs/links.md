---
title: Links
---

[Static analysis—what’s it good for?](http://techblog.realestate.com.au/static-analysis-whats-it-good-for/) - Michael Rowe

[Development Guidelines for Greenfield Implementation in sync with SAP Custom Code Management](https://archive.sap.com/documents/docs/DOC-56285)

[How to get contracted developers to read, accept and adhere to development guidelines?](https://answers.sap.com/questions/425130/how-to-get-contracted-developers-to-read-accept-an.html) - Bärbel Winkler

[Seven Ineffective Coding Habits of Many Programmers](https://www.youtube.com/watch?v=ZsHMHukIlJY) - Kevlin Henney

[Remote Code Analysis in ATC – How to write an ATC check](https://blogs.sap.com/2018/09/06/remote-code-analysis-in-atc-how-to-write-an-atc-check/) - Olga Dolinskaja

Report RS_CI_COMPARE
