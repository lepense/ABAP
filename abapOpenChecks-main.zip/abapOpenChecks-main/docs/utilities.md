---
title: Utilities
---

ZAOC_CLONES - Find cloned methods

ZAOC_PERFORMANCE - Performance Test

ZAOC_OPEN_TRANSPORT - Errors in open transports, with alerts per user, via customizable email

ZAOC_DATE_ANALYSIS - Date Analysis

ZAOC_CLEARANCE -

ZAOC_LINE_LENGTH -

ZAOC_LINES_TREE -

ZAOC_TADIR_CHECKS -

ZAOC_COUNT_CLASSES_WITH_TESTS -

ZAOC_ORPHANED_INCLUDES -

ZAOC_STRUCTURE_TEST -