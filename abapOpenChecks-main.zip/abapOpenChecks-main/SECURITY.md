# Reporting Security Issues

To report a security issue, please use the GitHub Security Advisory ["Report a Vulnerability"](https://github.com/larshp/abapOpenChecks/security/advisories/new) tab.
